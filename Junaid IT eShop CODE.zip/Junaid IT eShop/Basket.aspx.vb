﻿Public Class Basket
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not (Session("login") = True) Then Response.Redirect("Login.aspx")
        lblUsername.Text = Session("UserName")
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Protected Sub Logout_Click(sender As Object, e As EventArgs) Handles Logout.Click
        If (Session("login") = True) Then Session.Abandon()
        Response.Redirect("Login.aspx")
    End Sub
End Class