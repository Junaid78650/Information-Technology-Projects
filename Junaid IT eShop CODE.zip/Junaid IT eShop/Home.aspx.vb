﻿Public Class WebForm2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not (Session("login") = True) Then Response.Redirect("Login.aspx")
        lblUsername.Text = Session("UserName")


    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (Session("login") = True) Then Session.Abandon()
        Response.Redirect("Login.aspx")
    End Sub
End Class