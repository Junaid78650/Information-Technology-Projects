﻿Public Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("Login") = True Then
            lblAlready.Visible = True
            lblLogin.Visible = False
            TextBox1.Enabled = False
            TextBox2.Enabled = False
            Button1.Enabled = False

        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If GridView1.Rows.Count > 0 Then
            Session("Login") = True
            Session("UserName") = TextBox1.Text
            Response.Redirect("Home.aspx")

        End If
    End Sub
End Class