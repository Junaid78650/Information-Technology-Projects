﻿Imports System.Data.SqlClient
Imports System
Imports System.Configuration

Public Class Browse
    Inherits System.Web.UI.Page
    Dim con As New OleDb.OleDbConnection
    Dim counter As Integer = 0

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not (Session("login") = True) Then Response.Redirect("Login.aspx")
        lblUsername.Text = Session("UserName")

        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\junaidITdb.mdf;Integrated Security=SSPI;"

        Try
            Dim dt As New DataTable()

            Dim strConnString As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\junaidITdb.mdf;Integrated Security=SSPI;"

            Dim con As New SqlConnection(strConnString)

            Dim sda As New SqlDataAdapter()

            Dim query As String = "SELECT * FROM equipments"

            Dim cmd As New SqlCommand()

            cmd.CommandType = CommandType.Text

            cmd.CommandText = query

            cmd.Connection = con

            sda.SelectCommand = cmd

            sda.Fill(dt)

            GridView1.DataSource = dt

            GridView1.DataBind()



        Catch ex As SqlException

        Finally
            con.Dispose()
        End Try
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Protected Sub GridView1_SelectedIndexChanged1(sender As Object, e As EventArgs) Handles GridView1.SelectedIndexChanged

        Dim Rownum As Integer
        Rownum = GridView1.SelectedIndex
        Session("id") = GridView1.Rows(Rownum).Cells(1).Text
        Session("type") = GridView1.Rows(Rownum).Cells(2).Text
        Session("price") = GridView1.Rows(Rownum).Cells(4).Text
        SqlDataSource2.Insert()
    End Sub

    Protected Sub Logout_Click(sender As Object, e As EventArgs) Handles Logout.Click
        If (Session("login") = True) Then Session.Abandon()
        Response.Redirect("Login.aspx")
    End Sub

    Protected Sub ddSearch_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddSearch.SelectedIndexChanged

        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\junaidITdb.mdf;Integrated Security=SSPI;"

        Try
            Dim dt As New DataTable()

            Dim strConnString As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\junaidITdb.mdf;Integrated Security=SSPI;"

            Dim con As New SqlConnection(strConnString)

            Dim sda As New SqlDataAdapter()

            Dim query As String = "SELECT * FROM equipments where id =" + ddSearch.SelectedValue

            Dim cmd As New SqlCommand()

            cmd.CommandType = CommandType.Text

            cmd.CommandText = query

            cmd.Connection = con

            sda.SelectCommand = cmd

            sda.Fill(dt)

            GridView1.DataSource = dt

            GridView1.DataBind()



        Catch ex As SqlException

        Finally
            con.Dispose()
        End Try

    End Sub


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try

        Catch ex As SqlException

        Finally
            con.Dispose()
        End Try
    End Sub

    Protected Sub SqlDataSource2_Inserting(sender As Object, e As SqlDataSourceCommandEventArgs)
        If Session("counter") > 0 Then
            counter = Session("counter") + 1
        Else
            counter = counter + 1
        End If
        Session("counter") = counter
        lblcounter.Text = counter

    End Sub
End Class