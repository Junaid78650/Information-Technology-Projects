﻿CREATE TABLE [dbo].[equipments] (
    [Id]      INT         NOT NULL,
    [Type]    NCHAR (100) NULL,
    [Quality] NCHAR (100) NULL,
    [Price]   NCHAR (100) NULL,
    [image]   IMAGE NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

