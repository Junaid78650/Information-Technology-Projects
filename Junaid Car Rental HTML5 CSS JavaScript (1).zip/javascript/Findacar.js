    var myCars = [
					{Name: "Volvo XC60", Transmission: "Manual", Type: "SUV", Passengers: "5", Cost: "185", Image: "<img src='../media/1.jpg'  'height='180' width='300'>"},
					{Name: "Ford Kuga",Transmission: "Automatic", Type: "SUV", Passengers: "5", Cost: "92",Image: "<img src='../media/2.jpg'  'height='180' width='300'>"},
					{Name: "Range Rover Sport",Transmission: "Automatic", Type: "SUV", Passengers: "5", Cost: "240",Image: "<img src='../media/3.jpg'  'height='180' width='300'>"},
					{Name: "Seat Alhambra",Transmission: "Automatic", Type: "People Carrier", Passengers: "7", Cost: "200",Image: "<img src='../media/4.jpg'  'height='180' width='300'>"},
					{Name: "Toyota Aygo",Transmission: "Manual", Type: "Car", Passengers: "4", Cost: "53",Image: "<img src='../media/5.jpg'  'height='180' width='300'>"},
					{Name: "Ford Focus",Transmission: "Automatic", Type: "Car", Passengers: "5", Cost: "64",Image: "<img src='../media/6.jpg'  'height='180' width='300'>"},
					{Name: "Vauxhall Vivaro",Transmission: "Manual", Type: "Van", Passengers: "3", Cost: "60",Image: "<img src='../media/7.jpg'  'height='180' width='300'>"},
					{Name: "Renault Kangoo",Transmission: "Manual", Type: "Van", Passengers: "2", Cost: "50",Image: "<img src='../media/8.jpg'  'height='180' width='300'>"},
					{Name: "Citreon 2CV",Transmission: "Manual", Type: "Car", Passengers: "2", Cost: "30",Image: "<img src='../media/9.jpg'  'height='180' width='300'>"},
					{Name: "Lamborghini Huracan Spyder",Transmission: "Manual", Type: "Car", Passengers: "2", Cost: "2400",Image: "<img src='../media/10.jpg'  'height='180' width='300'>"},        
				];
				
	//The following event is for displaying all cars and it triggers when we select view all stock button
	 var btn = document.getElementById("searchbtnall");
    btn.addEventListener("click", viewall, false);

	function viewall()
    {
		DisplayMatchedCars(myCars);
	}

	//Global variables used for capturing user inputs
	var carname_searchvalue = "";
	var transmission_searchvalue = "";
	var type_searchvalue = "";
	var passengers_searchvalue ="";
	var cost_searchvalue ="";

	          
    //The following event is for matching cars and it triggers when we select some input and use search button
    var btn = document.getElementById("searchbtn");
    btn.addEventListener("click", matchCars, false);


    function matchCars()
    {
     // window.alert("step1!");  

			//Get all input values from the form 
            var carnameElement = document.getElementById("car_name");
            var carname = carnameElement.options[carnameElement.selectedIndex].value;
            var carnametext = carnameElement.options[carnameElement.selectedIndex].text;

            var cartransmissionElement = document.getElementById("transmission");
            var cartransmission = cartransmissionElement.options[cartransmissionElement.selectedIndex].value;
            var cartransmissiontext = cartransmissionElement.options[cartransmissionElement.selectedIndex].text;
        
            var cartypeElement = document.getElementById("type");
            var carttype = cartypeElement.options[cartypeElement.selectedIndex].value;
            var carttypeext = cartypeElement.options[cartypeElement.selectedIndex].text;

            
            var carpessengersElement = document.getElementById("passengers");
            var carpessengers = carpessengersElement.options[carpessengersElement.selectedIndex].value;
            var carpessengerstext = carpessengersElement.options[carpessengersElement.selectedIndex].text;

            var carcostElement = document.getElementById("cost");
            var carcost = carcostElement.options[carcostElement.selectedIndex].value;  
            var carcosttext = carcostElement.options[carcostElement.selectedIndex].text;  


            var searcharray = [];
            var searchcounter = 0;

			//set the initial values for global variables  
            if(carname != -1)
                {
                    
                    carname_searchvalue = carnametext;
                }
        
            if(cartransmission != -1)
                {
                    transmission_searchvalue = cartransmissiontext;
                }
            if(carttype != -1)
                {
                    type_searchvalue = carttypeext;
                }
            if(carpessengers != -1)
                {
                    passengers_searchvalue = carpessengerstext;
                }
            if(carcost != -1)
                {
                    cost_searchvalue = carcosttext;
                }
           
		//Create an array to store the matched cars   
		var matchedCars = []; 
		
		//if all the values are empty this means user didn't select any input values and tried to make a search so display an error message
		if(carname_searchvalue == "" && transmission_searchvalue == "" && type_searchvalue == "" && passengers_searchvalue == "" && cost_searchvalue == "")
		{
			window.alert("You must select at least one value to search or use view all stock option!");
			DisplayMatchedCars(matchedCars); //This is to clear the table if already printed 
		}
		else
		{
			for(var counter=0;counter<myCars.length;counter++)
            {
                var CarNameMatched=false;
                var CarTransmissionMatched=false;
                var CarTypeMatched = false;
                var CarPessengersMatched=false;
                var CarCostMatched=false;
                
				CarNameMatched = findNameInStock(myCars[counter].Name);
				CarTransmissionMatched = findTransmissionInStock(myCars[counter].Transmission);
				CarTypeMatched = findTypeInStock(myCars[counter].Type);
				CarPessengersMatched = findPassengersInStock(myCars[counter].Passengers);
				CarCostMatched = findCostInStock(myCars[counter].Cost);

				
                if(CarNameMatched && CarTransmissionMatched && CarTypeMatched && CarPessengersMatched && CarCostMatched)
                    {
						//window.alert(counter);
                        matchedCars.push(myCars[counter]);
                    }
            }
			if(matchedCars.length == 0) 
			{
				window.alert("No matching cars for the values selected - Algorithm uses AND for all the selected values!");
				DisplayMatchedCars(matchedCars); //This is to clear the table if already printed 
			}
			else
			{
				DisplayMatchedCars(matchedCars);
			}
		}
      
    }
function findNameInStock(carnameinstock)
{
//window.alert(carnameinstock);
//window.alert(carname_searchvalue);
	 if( (carname_searchvalue != "" && carname_searchvalue == carnameinstock ) || (carname_searchvalue == ""))
      {
           return true;
		   
      }
	  else
	  {
		  return false;
	  }
 //window.alert("end name function");
}
function findTransmissionInStock(transmissioninstock)
{
	//window.alert(transmissioninstock);
	if( (transmission_searchvalue != "" && transmission_searchvalue == transmissioninstock ) || (transmission_searchvalue == ""))
	{
		//window.alert("transmission True");
		return true;
	}
	else
	{
		//window.alert("transmission False");
		return false;
	}
}
function findTypeInStock(typeinstock)
{
	//window.alert(typeinstock);
	if( (type_searchvalue != "" && type_searchvalue == typeinstock ) || (type_searchvalue == ""))
	{
		return true;
	} 
	else
	{
		return false;
	}
}
function findPassengersInStock(passengersinstock)
{
	//window.alert(passengersinstock);
	if( (passengers_searchvalue != "" && passengers_searchvalue == passengersinstock ) || (passengers_searchvalue == ""))
	{
		return true;
	}
	else
	{
		return false;
	}
}
function findCostInStock(costinstock)
{
	//window.alert(costinstock);
  if( (cost_searchvalue != "" && cost_searchvalue == costinstock ) || (cost_searchvalue == ""))
	{
		return true;
	}
   else
   {
	   return false;
   }
			   
}

function DisplayMatchedCars(car)
{
	
           var matchingCarsTable = '<h1>MATCHING CARS</h1><table width="500" border="1" cellspacing="0">';
            var matchingCarsTable = matchingCarsTable + "<tr bgcolor='MAROON'><td>Name</td><td>Transmission</td><td>Type</td><td>Passengers</td><td>Cost</td><td>Image</td></tr>";
            
            for(i=0;i<car.length;i++) 
                {
                    
                    matchingCarsTable = matchingCarsTable + "<tr>";
                       
                                matchingCarsTable = matchingCarsTable + "<td>" + car[i].Name + "</td>";
								matchingCarsTable = matchingCarsTable + "<td>" + car[i].Transmission + "</td>";
								matchingCarsTable = matchingCarsTable + "<td>" + car[i].Type + "</td>";
								matchingCarsTable = matchingCarsTable + "<td>" + car[i].Passengers + "</td>";
								matchingCarsTable = matchingCarsTable + "<td>" + car[i].Cost + "</td>";
								matchingCarsTable = matchingCarsTable + "<td>" + car[i].Image +"</td>";                     
                     matchingCarsTable = matchingCarsTable + "</tr>";
                }
 
        matchingCarsTable = matchingCarsTable + "</table>"; 
        
        document.getElementById("matchedcars").innerHTML = matchingCarsTable;
		
}

