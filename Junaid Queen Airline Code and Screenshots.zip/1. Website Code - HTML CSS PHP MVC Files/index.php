<?php
include 'model/DBConnection.php';
require_once('controller/UserController.php');
require_once('model/UserModel.php');
require_once('controller/FlightController.php');
require_once('controller/CrewController.php');
$msg = "";
$op = $_REQUEST['op'];
if(isset($_REQUEST['msg']))
{
    $msg = $_REQUEST['msg'];
}
$flightController = new FlightController();
$user_controller = new UserController();
$crewController = new CrewController();
switch ($op)
{
    case 'showLogin':
        $user_controller->showLogin();
        break;
    case 'login':
        $email = $_POST['email'];
        $password = $_POST['password'];
        if ($user_controller->login($email, $password))
        {
            header("Location:index.php?op=home");
        }else{
            header("Location:index.php?op=showLogin&msg=Wrong User Name and Password.");
        }
        break;
    case 'logout':
        $user_controller->logout();
        break;
    case 'home':
        $flightController->listFlights();
        break;
    case 'search':
        $origin_id = $_POST['origin_id'];
        $destination_id = $_POST['destination_id'];
        $flights = $flightController->searchFlights($origin_id, $destination_id);
        echo json_encode($flights);
        break;
    case 'fdetail':
        $fid = $_REQUEST['fid'];
        $crewController->showFlightCrew($fid);
        break;
    case 'viewAddFlight':
        $flightController->viewAddFlight($msg);
        break;
    case 'viewAddCrew':
        $crewController->viewAddCrew($msg);
        break;
    case 'viewAssignCrew':
        $fid = $_REQUEST['fid'];
        $crewController->viewAssignCrew($fid, $msg);
        break;
    case 'addFlight':
        $origin_id = $_POST['origin_id'];
        $destination_id = $_POST['destination_id'];
        $departure_date = $_POST['departure_date'];
        $departure_time = $_POST['departure_time'];
        $arrival_date = $_POST['arrival_date'];
        $arrival_time = $_POST['arrival_time'];
        $flightController->addFlight($origin_id, $destination_id, $departure_date, $departure_time, $arrival_date, $arrival_time);
        break;
    case 'addCrew':
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $role_id = $_POST['role_id'];
        $crewController->addCrew($first_name, $last_name, $role_id);
        break;
    case 'addAssignCrew':
        $crew_id = $_POST['crew_id'];
        $flight_id = $_POST['flight_id'];
        $crewController->addAssignCrew($crew_id, $flight_id);
        break;
    case 'new':
        $filmController->saveRecord();
        break;
    default:
        //$user_controller = new UserController();
        header("Location:index.php?op=showLogin");
        break;
}