<?php
require_once ('model/UserModel.php');
class UserController
{
    function UserController()
    {

    }

    function login($email, $password)
    {
        $authentic = false;
        $user = new User();
        $user = $user->login($email, $password);
        if($email == "")
        {
            $authentic = false;
        }
        elseif($password == "")
        {
            $authentic = false;
        }
        elseif($user['role'] == "")
        {
            $authentic = false;
        }
        else
        {
            session_start();
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $authentic = true;
        }
        return $authentic;

    }

    function showLogin()
    {
        session_start();
        if(empty($_SESSION['user_email'])){
        include 'view/login.php';
        }
        else
        {
            header("Location:index.php?op=home");
        }
    }
    
    static function authenticate($e, $p)
    {
        $authentic = false;
        $user = new User();
        $user = $user->login($e, $p);
        if ($user->login($e, $p))
        {
           echo "here";die();
            $authentic = true;
        }
        return $authentic;

    }

    function logout()
    {
        session_start();
        session_destroy();
        header("Location:index.php?op=showLogin");
    }


}
