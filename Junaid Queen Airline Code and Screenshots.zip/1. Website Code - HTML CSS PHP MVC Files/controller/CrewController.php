<?php

require_once 'model/CrewModel.php';
require_once 'model/CrewRoleModel.php';
class CrewController
{
    function showFlightCrew($fid)
    {
        $crew = new Crew();
        $crewDetail = $crew->getFlightCrewDetail($fid);
        session_start();
        include 'view/ViewCrewDetails.php';
    }

    public function viewAddCrew($msg)
    {   
        session_start();
        $crewRole = new CrewRole();
        $crewRoles = $crewRole->getCrewRole();
        include 'view/InsertCrew.php';
    }

    public function viewAssignCrew($fid, $msg)
    {   
        session_start();
        $crew= new Crew();
        $crews = $crew->getAllCrewDetail();
        $flight_id = $fid;
        include 'view/AllocateCrew.php';
    }
    public function addCrew($first_name, $last_name, $role_id)
    {
        $crew = new Crew();
        $msg = "";
        if($first_name == "")
        {
            $msg = "Enter First Name";
        }
        elseif($last_name == "")
        {
            $msg = "Enter Last Name";
        }
        elseif($role_id == "")
        {
            $msg = "Choose a Role";
        }
        elseif($crew->insertCrew($first_name, $last_name, $role_id))
        {
            $msg = "Crew Added Successfully.";
        }
        else {
            $msg = "Unknown Error.";
        }

        header("Location:index.php?op=viewAddCrew&msg=".$msg);
    }

    public function addAssignCrew($crew_id, $flight_id)
    {
        $crew = new Crew();
        $msg = "";
        if($crew_id == "")
        {
            $msg = "Select a Crew";
        }
        elseif($flight_id == "")
        {
            $msg = "Flight not found";
        }
        elseif($crew->insertFlightCrew($crew_id, $flight_id))
        {
            $msg = "Crew Added Successfully.";
        }
        else {
            $msg = "Unknown Error.";
        }

        header("Location:index.php?op=viewAssignCrew&fid=".$flight_id."&msg=".$msg);
    }
}