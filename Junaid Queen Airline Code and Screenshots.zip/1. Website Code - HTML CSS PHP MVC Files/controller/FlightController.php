<?php

require_once 'model/FlightsModel.php';
require_once 'model/AirportModel.php';
class FlightController
{
    private $flightModel = NULL;

    public function __construct() {
        $this->flightModel = new Flight();
    }

    public function addFlight($origin_id, $destination_id, $departure_date, $departure_time, $arrival_date, $arrival_time)
    {
        $msg = "";

        if(!$this->checkDate($departure_date, $departure_time, $arrival_date, $arrival_time))
        {
            $msg = "Interval should be more than 2 Hours. Problem in Arrival or Departure Date and Time.";
        }
        elseif($origin_id == $destination_id)
        {
            $msg = "Origin and Destination Should be different.";
        }
        elseif($this->flightModel->insertFlight($origin_id, $destination_id, $departure_date, $departure_time, $arrival_date, $arrival_time))
        {
            $msg = "Successfully Added.";
        }
        else
        {
            $msg = "Unknown Error.";
        }
        
        header("Location:index.php?op=viewAddFlight&msg=".$msg);
    }
    
    function checkDate($departure_date, $departure_time, $arrival_date, $arrival_time)
    {
        $status = false;
        date_default_timezone_set('UTC');
        $d_date = date("d,m,Y", strtotime($departure_date));  
        $d_time = str_replace(':', ',', $departure_time);
        $t_d_date = $d_time.',0,'.$d_date;
        $full_d_date = explode(',',$t_d_date);
        $d_h = $full_d_date[0];
        $d_i = $full_d_date[1];
        $d_s = $full_d_date[2];
        $d_d = $full_d_date[3];
        $d_m = $full_d_date[4];
        $d_y = $full_d_date[5];

        $a_date = date("d,m,Y", strtotime($arrival_date));  
        $a_time = str_replace(':', ',', $arrival_time);
        $t_a_date = $a_time.',0,'.$a_date;
        $full_a_date = explode(',',$t_a_date);
        $a_h = $full_a_date[0];
        $a_i = $full_a_date[1];
        $a_s = $full_a_date[2];
        $a_d = $full_a_date[3];
        $a_m = $full_a_date[4];
        $a_y = $full_a_date[5];
        $result_departure_date = date("h-i-s-Y-m-d",mktime($d_h,$d_i,$d_s,$d_m,$d_d,$d_y));
        $result_arrival_date = date("h-i-s-Y-m-d",mktime($a_h,$a_i,$a_s,$a_m,$a_d,$a_y));
        $date1 = new DateTime($departure_date . " " . $departure_time);
        $date2 = new DateTime($arrival_date. " " . $arrival_time);
        $interval = $date1->diff($date2);

        if($interval->h < 2)
        {
            $status = false;
        }
        else
        {
            $status = true;
        }
        
        return $status;
    }

    public function viewAddFlight($msg)
    {   
        session_start();
        $airports = new Airport();
        $airportDetail = $airports->getAllAirport();
        include 'view/InsertFlight.php';
    }

    public function listFlights() 
    {
        session_start();
        if(!empty($_SESSION['user_email']))
        {
        $flights = $this->flightModel->getAllFlights();
        $airports = new Airport();
        $airportDetail = $airports->getAllAirport();
        include 'view/FlightView.php';
        }
        else
        {
            header("Location:index.php?op=logout");
        }
    }

    public function searchFlights($origin_id, $destination_id)
    {
        session_start();
        $flights = $this->flightModel->getSearchFlights($origin_id, $destination_id);
        return $flights;
    }


}