<?php
include "HeaderView.php";
include "NavigationBar.php";
?>
<div class="container">
<h1 class="head">Crew Detail</h1>
    <table class="table" >
        <thead>
            <th>Sr.</th>
            <th>Crew Name</th>
            <th>Crew Role</th>
        </thead>
        
        <?php
        $sr = 1;
        foreach ($crewDetail as $crew) { ?>
        <tr>
            <td><?php echo $sr++; ?></td>
            <td><?php echo $crew->crew_fname. ' ' .$crew->crew_lname; ?></td>
            <td><?php echo $crew->role_name; ?></td>
        </tr>
        <?php } ?>
        
    </table>
</div>
<?php
include "FooterView.php";
?>