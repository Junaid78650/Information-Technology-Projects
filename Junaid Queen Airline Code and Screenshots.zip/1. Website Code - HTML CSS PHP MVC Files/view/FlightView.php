<?php
include "HeaderView.php";
include "NavigationBar.php";
?>
<div class="container">
<h1 class="head">FLIGHT SCHEDULE</h1>
 <?php if($_SESSION['user_role'] == 1){ ?>
       <h3 class="head">YOU ARE A STANDARD USER</h2>
        <?php } ?>
 <?php if($_SESSION['user_role'] == 2){ ?>
       <h3 class="head">YOU ARE AN ADMIN USER</h2>
        <?php } ?>
</center>
    <div class="col-md-12 search">
    <div class="col-md-5 searchboxes">
        <select class="form-control" name="origin_id" id="origin_id" style="width: 100%;background: lightgrey">
            <option value="">Select Origin</option>
            <?php foreach ($airportDetail as $airport) { ?>
            <option value="<?php echo $airport->id ?>"><?php echo $airport->location . ' ('. $airport->location . ')'?></option>
            <?php } ?>
        </select>
    </div>
    <div class="col-md-5 searchboxes">    
        <select class="form-control" name="destination_id" id="destination_id" style="width: 100%;background: lightgrey">
            <option value="">Select Destination</option>
            <?php foreach ($airportDetail as $airport) { ?>
            <option value="<?php echo $airport->id ?>"><?php echo $airport->location . ' ('. $airport->location . ')'?></option>
            <?php } ?>
        </select>
    </div> 
    <div class="col-md-1 searchboxesbtn"> <button type="submit" id="search_btn" class="signout" style="margin-top: 25px;">Search </button></div>   
    </div>
    <table class="table" >
        <thead>
            <th width="20%">Origin</th>
            <th width="20%">Destination</th>
            <th width="10%">DepartDate</th>
            <th width="10%">DepartTime</th>
            <th width="10%">ArriveDate</th>
            <th width="10%">ArriveTime</th>
            <th width="20%">Crew Details</th>
        </thead>
        <tbody id="flight_record">
        <?php foreach ($flights as $flight) { ?>

        <tr>
        <td width="20%"><?php echo $flight->origin_location . ', ' .$flight->origin_name; ?></td>
        <td width="20%"><?php echo $flight->departure_location. ', ' .$flight->departure_name; ?></td>
        <td width="10%"><?php echo $flight->departure_date; ?></td>
        <td width="10%"><?php echo $flight->departure_time; ?></td>
        <td width="10%"><?php echo $flight->arrival_date; ?></td>
        <td width="10%"><?php echo $flight->arrival_time; ?></td>
        <td width="20%"><a class="show" href="index.php?op=fdetail&fid=<?php echo $flight->f_id; ?>">View</a> <?php if($_SESSION['user_role'] == 2){ ?> | <a class="assign" href="index.php?op=viewAssignCrew&fid=<?php echo $flight->f_id; ?>">Allocate Crew</a><?php } ?></td>
        </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php
include "FooterView.php";
?>

<script>
    $(document).ready(function(){
        $("#search_btn").click(function(){
            
            var origin_id = $("#origin_id").val();
            var destination_id = $("#destination_id").val();
            
            var dataString = 'origin_id='+ origin_id + '&destination_id='+ destination_id;
            if(origin_id == '' || destination_id == '')
            {
            alert("Please Fill All Fields");
            }
            else
            {
            // AJAX Code To Submit Form.
            $.ajax({
            type: "POST",
            url: "index.php?op=search",
            data: dataString,
            cache: false,
            success: function(result){
                    var records = JSON.parse(result);
        var text = '<tbody id="flight_record">';
                 jQuery.each(records, function(key,value){
                          // console.log(value.ponumber);

                          text += '<tr>'+
        '<td style="background-color:black" width="20%">' + value.origin_location + ' ' + value.origin_name + '</td>'+
        '<td style="background-color:black" width="20%">' + value.departure_location + ' ' + value.departure_name + '</td>'+
        '<td style="background-color:black" width="10%">' + value.departure_date + '</td>'+
        '<td style="background-color:black" width="10%">' + value.departure_time + '</td>'+
        '<td style="background-color:black" width="10%">' + value.arrival_date + '</td>'+
        '<td style="background-color:black" width="10%">' + value.arrival_time + '</td>'+
        '<td style="background-color:black" width="20%"><a class="show" href="index.php?op=fdetail&fid=' + value.f_id + '">Show</a>' +
         <?php if($_SESSION['user_role'] == 2){ ?>' | <a class="assign" href="index.php?op=viewAssignCrew&fid=' + 
         <?php echo $flight->f_id; ?> + '">Assign Crew</a>' +
         <?php } ?>'</td>'+
        '</tr>';

        
               });
               text += '</tbody>';
            //    $('#flight_record').remove(); 
            //       $('#flight_record').append(text);
                  $("#flight_record").replaceWith(text);
            }
            });
            }
            return false;
        });
    });
</script>
