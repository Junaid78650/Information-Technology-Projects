<nav class="navbar navbar-expand-lg navbar-light bg-light">
 <img class="logo" src="images/logo6.jpg" alt="logo">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
  <?php if(isset($_SESSION['user_email'])){ ?>
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php?op=home">Home<span class="sr-only">(current)</span></a>
      </li>
      <?php if($_SESSION['user_role'] == 2){ ?>
      <li class="nav-item">
        <a class="nav-link" href="index.php?op=viewAddFlight">  Add Flight </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="index.php?op=viewAddCrew"> Add Crew</a>
      </li>
      <?php } ?>
    </ul>
    <a href="index.php?op=logout"><button class="signout" type="submit">Sign out</button></a>
    <?php } ?>
  </div>
</nav>