<?php
include "HeaderView.php";
include "NavigationBar.php";
?>
<form action="index.php?op=addAssignCrew" method="post">
  <div class="container">
    <h1 class="head">Assign Crew</h1>
    <center>
    <hr>
    <input value="<?php echo $flight_id; ?>" type="hidden" name="flight_id">
    <label for="crew_id"><b>Choose Crew</b></label>
    <select class="form-control" name="crew_id">
        <option>Select Crew</option>
        <?php foreach ($crews as $crew) { ?>
            <option value="<?php echo $crew->crew_id ?>"><?php echo $crew->crew_fname . " " . $crew->crew_lname ." (". $crew->role_name . ")"?></option>
        <?php } ?>
    </select>
    <br>
    <button type="submit" class="btn btn-primary">Assign Crew</button>
    </center>
  </div>
</form>
<?php
include "FooterView.php";
if($msg != ""){
  echo '<script type="text/javascript">';
  echo ' alert("'.$msg.'")';  //not showing an alert box.
  echo '</script>';
  }
?>