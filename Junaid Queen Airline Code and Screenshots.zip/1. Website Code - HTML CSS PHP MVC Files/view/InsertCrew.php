<?php
include "HeaderView.php";
include "NavigationBar.php";
?>
<form action="index.php?op=addCrew" method="post">
  <div class="container">
    <h1 class="head">Add Crew</h1>
    <hr>
    <center>
    <label for="first_name"><b>First Name</b></label>
    <input class="form-control" type="text" name="first_name">
    <br>
    <label for="last_name"><b>Last Name</b></label>
    <input class="form-control" type="text" name="last_name">
    <br>
    <label for="role_id"><b>Choose Role</b></label>
    <select class="form-control" name="role_id">
        <option>Select Role</option>
        <?php foreach ($crewRoles as $roles) { ?>
            <option value="<?php echo $roles->id ?>"><?php echo $roles->name?></option>
        <?php } ?>
    </select>
    <br>  
    <button type="submit" class="btn btn-primary">Add Crew</button>
    </center>
  </div>
</form>
<?php
include "FooterView.php";
if($msg != ""){
  echo '<script type="text/javascript">';
  echo ' alert("'.$msg.'")';  //not showing an alert box.
  echo '</script>';
  }
?>