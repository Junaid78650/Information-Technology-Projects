<?php
include "HeaderView.php";
include "NavigationBar.php";
?>
<form action="index.php?op=login" method="post">
  <div class="container">
    <center>
    <h1 class="head">HOME</h1>
    
    <hr>
      <label for="email"><b>Email</b></label>
    <input type="text" class="form-control" placeholder="Enter Email" name="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" class="form-control" placeholder="Enter Password" name="password" required>
    <button type="submit" class="show">Login</button>
	
	<h4 style="color:red;">USE THE FOLLOWING LOGIN DETAILS FOR TESTING</h4>
	  <table class="login_credentials table2" border="1">
    <th>Username</th>
    <th>Password</th>
    <th>Type of User</th>

    <tr>
      <td>y.miandad@assign3.ac.uk</td>
      <td>letmein</td>
      <td>Admin</td>
    </tr>
    <tr>
      <td>k.l.hutton@assign3.ac.uk</td>
      <td>password</td>
      <td>Standard User</td>
    </tr>
  </table>

  </div>
  </center>
</form>
<?php
include "FooterView.php";
if(!empty($msg)){
  echo '<script type="text/javascript">';
  echo ' alert("'.$msg.'")'; 
  echo '</script>';
  }
?>