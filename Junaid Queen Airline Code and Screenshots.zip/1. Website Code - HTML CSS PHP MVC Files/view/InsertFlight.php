<?php
include "HeaderView.php";
include "NavigationBar.php";
?>
<form action="index.php?op=addFlight" method="post">
  <div class="container">
    <h1 class="head">Add Flight</h1>
    <center>
    <p class="details">
        <b>1. </b>Origin and Destination can't be same. <br>
        <b>2. </b>There should be at least more than 2 hour interval between flights. <br>
    </p>
</center>
    <hr>
<center>
    <label for="origin_id"><b>Choose Origin</b></label>
    <select class="form-control" name="origin_id">
        <option>Select Origin</option>
        <?php foreach ($airportDetail as $airport) { ?>
            <option value="<?php echo $airport->id ?>"><?php echo $airport->location . ' ('. $airport->location . ')'?></option>
        <?php } ?>
    </select>
    <br>
    <label for="destination_id"><b>Choose Destination</b></label>
    <select class="form-control" name="destination_id">
        <option>Select Destination</option>
        <?php foreach ($airportDetail as $airport) { ?>
        <option value="<?php echo $airport->id ?>"><?php echo $airport->location . ' ('. $airport->location . ')'?></option>
        <?php } ?>
    </select>
    <br>
    <label for="departure_date"><b>Departure Date</b></label>
    <input class="form-control" type="date" name="departure_date" required>
    <br>
    <label for="departure_time"><b>Departure Time</b></label>
    <input class="form-control" type="time" name="departure_time" required>
    <br>
    <label for="arrival_date"><b>Arrival Date</b></label>
    <input class="form-control" type="date" name="arrival_date" required>
    <br>
    <label for="arrival_time"><b>Arrival Time</b></label>
    <input class="form-control" type="time" name="arrival_time" required>



    <button type="submit" class="btn btn-primary">Add Flight</button>
    </center>
  </div>
</form>
<?php
include "FooterView.php";
if($msg != ""){
echo '<script type="text/javascript">';
echo ' alert("'.$msg.'")';  //not showing an alert box.
echo '</script>';
}
?>