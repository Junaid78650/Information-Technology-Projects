<?php

class Airport
{
    private $db = NULL;

    public function __construct() {
        $this->db = new DBConnection();
    }
        
    public function getAllAirport() {
        $airports = array(); 
        $conn = $this->db->openDb(); 
        $query = "SELECT * FROM airports";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        while($airport = $stmt->fetchObject())
        $airports[] = $airport;
        return $airports;
    }
}