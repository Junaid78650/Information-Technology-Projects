<?php
//include 'DBConnection.php';

class User
{

    function login($email, $password)
    {
        $db = new DBConnection();
        $db = $db->openDb();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->bindValue(':email',$email);
        $stmt->execute();
        $authentic=false;
        if($row = $stmt->fetch()){
            			
				 if (password_verify($password, $row['password'])) {
                  $authentic=true;
            }
        }
        if($authentic){
        return $row;
        }
        else{
            return false;
        }

    }
    
}