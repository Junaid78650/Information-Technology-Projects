<?php

class CrewRole
{
    private $db = NULL;

    public function __construct() {
        $this->db = new DBConnection();
    }
        
    public function getCrewRole() {
        $roles = array(); 
        $conn = $this->db->openDb(); 
        $query = "SELECT * FROM roles";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        while($role = $stmt->fetchObject())
        $roles[] = $role;
        return $roles;
    }
}