<?php

class DBConnection {
    private $conn;
    public function openDb() {
        require_once 'db/Config.php';
        $this->conn = new PDO('mysql:host='.DB_HOST.';dbname='.DB_DATABASE.'', DB_USER, DB_PASSWORD);
        return $this->conn;
    }

    public function closeDb() {
        $this->conn = null;
    }
}

?>
