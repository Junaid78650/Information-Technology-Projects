<?php

class Crew
{
    private $db = NULL;

    public function __construct() {
        $this->db = new DBConnection();
    }
    public function getAllCrewDetail() {
        $crewDetails = array(); 
        $conn = $this->db->openDb(); 
        $query = "SELECT c.id as crew_id, c.first_name as crew_fname, c.last_name as crew_lname, r.name as role_name
        FROM crew c
        LEFT JOIN 
           roles r
               ON r.id = c.role_id";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        while($crewDetail = $stmt->fetchObject())
        $crewDetails[] = $crewDetail;
        return $crewDetails;
    }

    public function getFlightCrewDetail($id) {
        $crewDetails = array(); 
        $conn = $this->db->openDb(); 
        $query = "SELECT c.first_name as crew_fname, c.last_name as crew_lname, r.name as role_name
        FROM crew_flight cf
        LEFT JOIN 
           crew c
               ON c.id = cf.crew_id
        LEFT JOIN 
            roles r
               ON r.id = c.role_id
        WHERE cf.flight_id = ".$id;
        $stmt = $conn->prepare($query);
        $stmt->execute();
        while($crewDetail = $stmt->fetchObject())
        $crewDetails[] = $crewDetail;
        return $crewDetails;
    }


    function insertCrew($first_name, $last_name, $role_id)
    {
        $conn = $this->db->openDb(); 
        $query="INSERT INTO crew (first_name, last_name, role_id) VALUES (:first_name, :last_name, :role_id)";
        $stmt=$conn->prepare($query);
        $stmt->bindValue(':first_name', $first_name);
        $stmt->bindValue(':last_name', $last_name);
        $stmt->bindValue(':role_id', $role_id);
        return $stmt->execute();
    }
    
    function insertFlightCrew($crew_id, $flight_id)
    {
        $conn = $this->db->openDb(); 
        $query="INSERT INTO crew_flight (crew_id, flight_id) VALUES (:crew_id, :flight_id)";
        $stmt=$conn->prepare($query);
        $stmt->bindValue(':crew_id', $crew_id);
        $stmt->bindValue(':flight_id', $flight_id);
        return $stmt->execute();
    }
}