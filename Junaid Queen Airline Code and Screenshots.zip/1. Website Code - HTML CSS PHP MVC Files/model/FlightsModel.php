<?php

class Flight
{

    private $db = NULL;

    public function __construct() {
        $this->db = new DBConnection();
    }
        
    public function getAllFlights() {
        $flights = array(); 
        $conn = $this->db->openDb(); 
        $query = "SELECT f.id as f_id, f.departure_date, f.departure_time, f.arrival_date, f.arrival_time ,oa.name as origin_name, oa.location as origin_location, da.name as departure_name, da.location as departure_location
        FROM flights f
        LEFT JOIN 
           airports oa
               ON oa.id = f.origin_id
        LEFT JOIN 
            airports da
               ON da.id = f.destination_id";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        while($flight = $stmt->fetchObject())
        $flights[] = $flight;
        // print_r($flights);die();
        return $flights;
    }

    public function getSearchFlights($origin_id, $destination_id) {
        $flights = array(); 
        $conn = $this->db->openDb(); 
        $query = "SELECT f.id as f_id, f.departure_date, f.departure_time, f.arrival_date, f.arrival_time ,oa.name as origin_name, oa.location as origin_location, da.name as departure_name, da.location as departure_location
        FROM flights f
        LEFT JOIN 
           airports oa
               ON oa.id = f.origin_id
        LEFT JOIN 
            airports da
               ON da.id = f.destination_id
        WHERE f.origin_id = " . $origin_id . " AND f.destination_id = ". $destination_id;
        $stmt = $conn->prepare($query);
        $stmt->execute();
        while($flight = $stmt->fetchObject())
        $flights[] = $flight;
        // print_r($flights);die();
        return $flights;
    }

    function insertFlight($origin_id, $destination_id, $departure_date, $departure_time, $arrival_date, $arrival_time)
    {
        $conn = $this->db->openDb(); 
        $query="INSERT INTO flights (origin_id, destination_id, departure_date, departure_time, arrival_date, arrival_time) VALUES (:origin_id, :destination_id, :departure_date, :departure_time, :arrival_date, :arrival_time)";
        $stmt=$conn->prepare($query);
        $stmt->bindValue(':origin_id', $origin_id);
        $stmt->bindValue(':destination_id', $destination_id);
        $stmt->bindValue(':departure_date', $departure_date);
        $stmt->bindValue(':departure_time', $departure_time);
        $stmt->bindValue(':arrival_date', $arrival_date);
        $stmt->bindValue(':arrival_time', $arrival_time);
        return $stmt->execute();
    }
}

